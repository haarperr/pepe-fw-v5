Config = {}

Config.Hunting = {
	vec(-678.7621, 5837.982, 17.33)
}

Config.Butcher = {
	vec(-66.8, 6237.96, 31.09)
}

Config.HuntWeapons = {
	GetHashKey("weapon_knife"),
   }

Config.zones = {
		{
			coords = {x = -1319.486, y = 4731.628, z = 79.08},
			zone = {radius = 400.0, color = 1}, 
			blip = {draw = true, id = 0, color = 0, text = ""}
		},
		-- {
		-- 	coords = {x = -1833.11, y = -1214.88, z = 13.02}, 
		-- 	zone = {radius = 300.0, color = 1}, 
		-- 	blip = {draw = true, id = 304, color = 1, text = "Zone"}
		-- },
		-- {
		-- 	coords = {x = 73.29, y = 6536.86, z = 31.68}, 
		-- 	zone = {radius = 100.0, color = 2}, 
		-- 	blip = {draw = true, id = 304, color = 2, text = "Zone 2"}
		-- }
	
}