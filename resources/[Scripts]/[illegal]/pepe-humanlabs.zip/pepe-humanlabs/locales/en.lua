Locales['en'] = {
	["stealstuff"]  = "~g~E~s~ - Steal stuff",
	["nocops"]  = "Not enough cops.. (4 needed)",
	["missingsomething"]  = "Your missing an item..",
	["nohack"]  = "It appears you are not able to hack this..",
	["blown"]  = "Door blown up",
	["lockdownactive"]  = "Lockdown active breaking open is not possible",
	["notclose"]  = "Not close enough.",
	["failed"]  = "You failed",
	["policeheader"]  = "Humane Labs Robbery",
	["blipmsg"]  = "911 - Suspected situation",
	["blipdetail"]  = "Humane Labs Robbery",
	["searchinglocker"]  = "Searching Locker..",
	["cancelled"]  = "Cancelled",
	["blipp1"]  = "Humane Labs & Research",
}
-- _U("cuffed") .."
--                         _U("unknown_account")