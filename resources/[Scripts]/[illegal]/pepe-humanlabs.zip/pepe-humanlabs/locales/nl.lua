Locales['nl'] = {
	["stealstuff"]  = "~g~E~s~ - Spullen Stelen",
	["nocops"]  = "Niet genoeg politie.. (4 nodig)",
	["missingsomething"]  = "Je mist een item..",
	["nohack"]  = "Het lijkt erop dat je deze computer niet kan hacken..",
	["blown"]  = "Deur opgeblazen",
	["lockdownactive"]  = "Lockdown actief openbreken niet mogelijk!",
	["notclose"]  = "Je bent niet dichtbij genoeg..",
	["failed"]  = "Je hebt gefaald",
	["policeheader"]  = "Humane Labs Melding",
	["blipmsg"]  = "112 - Verdachte situatie Humane Labs",
	["blipdetail"]  = "Humane Labs Overval",
	["searchinglocker"]  = "Kastje Doorzoeken..",
	["cancelled"]  = "Geannuleerd",
	["blipp1"]  = "Humane Labs & Research",
}
-- _U("cuffed") .."
--                         _U("unknown_account")